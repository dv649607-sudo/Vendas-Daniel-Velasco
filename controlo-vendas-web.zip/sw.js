// Service worker: guarda a app no telemóvel para abrir sem internet.
// Quando mudar o index.html, suba também este ficheiro com CACHE diferente (v2, v3...).
const CACHE = "controlo-vendas-v1";
const FICHEIROS = ["./", "./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FICHEIROS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.open(CACHE).then(async c => {
      const guardado = await c.match(e.request);
      const rede = fetch(e.request)
        .then(r => { if (r && r.ok && new URL(e.request.url).origin === location.origin) c.put(e.request, r.clone()); return r; })
        .catch(() => guardado);
      return guardado || rede;
    })
  );
});
